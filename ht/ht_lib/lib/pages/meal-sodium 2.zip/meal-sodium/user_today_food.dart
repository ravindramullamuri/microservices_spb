import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../constants/heart_thrive_strings_constants.dart';
import '../../constants/ui_constants.dart';
import '../../models/home/meal_type_nutrient_model.dart';
import '../../models/meal/edit_meal_model.dart';
import '../../models/meal/food/food_response_model.dart';
import '../../models/meal/food/nutrients_model.dart';
import '../../providers/meal/meal_sodium_provider.dart';
import '../../routes/app_router.dart';
import '../../services/meal_services.dart';
import '../../theme/app_theme.dart';
import 'browse_food_page.dart';

// =======================
// MEAL LOGS PAGE - NOW CONSUMER WIDGET
// =======================

class MealLogsPage extends ConsumerStatefulWidget {
  final int? initialIndex;
  final String? pageType;

  const MealLogsPage({
    super.key,
    this.initialIndex,
    this.pageType,
  });


  @override
  ConsumerState<MealLogsPage> createState() => _MealLogsPageState();
}

class _MealLogsPageState extends ConsumerState<MealLogsPage> {
  final ScrollController _controller = ScrollController();

  ///  Selected meal index (0 = All)
  int _selectedMealIndex = 0;

  ///  Meal tabs
  final List<Map<String, dynamic>> _mealTabs = [
    {"title": "All Meal", "icon": 'lib/assets/All Meal.png'},
    {"title": "Breakfast", "icon": 'lib/assets/breakfast.png'},
    {"title": "Lunch", "icon": 'lib/assets/Lunch.png'},
    {"title": "Snacks", "icon": 'lib/assets/snacks.png'},
    {"title": "Dinner", "icon": 'lib/assets/dinner.png'},
  ];

  bool _isTodaySelected = true;

  @override
  void initState() {
    super.initState();
    _controller.addListener(_onScroll);
    _selectedMealIndex = widget.initialIndex ?? 0;
  }

  void _onScroll() {
    if (_controller.position.pixels >= _controller.position.maxScrollExtent - 200) {
      ref.read(mealLogsProvider.notifier).loadMoreLogs();
    }
  }

  @override
  void dispose() {
    _controller.removeListener(_onScroll);
    _controller.dispose();
    //ref.read(mealLogsProvider.notifier).dispose();
    //ref.read(todayNutrientProvider.future);
    super.dispose();
  }

  List<FoodLogEntry> getFilteredLogs(List<FoodLogEntry> logs) {
    if (_selectedMealIndex == 0) return logs;

    final selectedMeal = _mealTabs[_selectedMealIndex]["title"].toString().toLowerCase();

    return logs.where((e) {
      final mealName = e.mealType?.name?.toLowerCase() ?? '';
      return mealName == selectedMeal;
    }).toList();
  }

  Widget _buildMealTabs() {
    return SizedBox(
      height: 110,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: List.generate(_mealTabs.length, (index) {
          final tab = _mealTabs[index];
          final bool isSelected = _selectedMealIndex == index;

          return Expanded(
            child: GestureDetector(
              onTap: () => setState(() => _selectedMealIndex = index),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Container(
                    width: deviceWidth(context) > 390 ? 56 : 40,
                    height: deviceWidth(context) > 390 ? 56 : 40,
                    decoration: BoxDecoration(
                      color: Colors.white,
                      shape: BoxShape.circle,
                      border: isSelected ? Border.all(color: AppTheme.primaryColor, width: 1) : null,
                      boxShadow: const [BoxShadow(color: Colors.black12, blurRadius: 6, offset: Offset(0, 3))],
                    ),
                    child: Center(
                      child: Image.asset(
                        tab["icon"],
                        width: deviceWidth(context) > 390 ? 26 : 20,
                        color: isSelected ? AppTheme.primaryColor : Colors.grey.shade600,
                      ),
                    ),
                  ),
                  const SizedBox(height: 8),
                  isSelected
                      ? Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 3),
                    decoration: BoxDecoration(color: AppTheme.primaryColor, borderRadius: BorderRadius.circular(18)),
                    child: Text(tab["title"], style:  AppTheme.title12.copyWith(fontSize: deviceWidth(context) > 390?12:10,color: Colors.white)),
                  )
                      : Text(tab["title"], style: AppTheme.title12.copyWith(fontSize: deviceWidth(context) > 390?12:10, color: Colors.black87)),
                ],
              ),
            ),
          );
        }),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    print('UI start : ${DateTime.now()}');
    final nutrientAsync = ref.watch(todayNutrientProvider);
    final logsAsync = ref.watch(mealLogsProvider);

    return Scaffold(
      appBar: AppBar(
          title: const Text('Today Meal Logs'),
      ),
      body: Column(
        children: [
          // Daily Intake Card
          Container(
            margin: const EdgeInsets.symmetric(horizontal: 10.0, vertical: 10),
            padding: const EdgeInsets.all(5.0),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(12.0),
              boxShadow: [BoxShadow(color: Colors.grey.shade300, spreadRadius: 1, blurRadius: 6, offset: const Offset(0, 3))],
            ),
            child: nutrientAsync.when(
              loading: () => const SizedBox(
                  height: 150,
                  child: Center(
                  child: CircularProgressIndicator()
              )),
              error: (e, _) => Text("Error loading nutrients: $e"),
              data: (nutrients) => DailyMealIntakeCard(nutrients: nutrients),
            ),
          ),

          // Logs Section
          Expanded(
            child: Container(
              margin: const EdgeInsets.symmetric(horizontal: 10.0, vertical: 10),
              padding: const EdgeInsets.all(5.0),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(12.0),
                boxShadow: [BoxShadow(color: Colors.grey.shade300, spreadRadius: 1, blurRadius: 6, offset: const Offset(0, 3))],
              ),
              child: Column(
                children: [
                  _buildFoodToggle(),
                  _buildMealTabs(),
                  Expanded(
                    child: logsAsync.when(
                      loading: () => const Center(child: CircularProgressIndicator()),
                      error: (e, _) => Center(child: Text("Error: $e")),
                      data: (logs) {
                        print('UI End : ${DateTime.now()}');
                        final filteredLogs = getFilteredLogs(logs);

                        if (filteredLogs.isEmpty) {
                          return _buildEmptyUI(index: _selectedMealIndex == 0 ? null : _selectedMealIndex);
                        }

                        return ListView.builder(
                          controller: _controller,
                          itemCount: filteredLogs.length + (logsAsync.isLoading ? 1 : 0),
                          itemBuilder: (context, index) {
                            if (index >= filteredLogs.length) {
                              return const Padding(padding: EdgeInsets.all(16), child: Center(child: CircularProgressIndicator()));
                            }
                            return Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: FoodNutrientsCard(foodLogEntry: filteredLogs[index]),
                            );
                          },
                        );
                      },
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildFoodToggle() {
    return Container(
      padding: const EdgeInsets.all(6),
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16), boxShadow: const [
        BoxShadow(color: Colors.black12, blurRadius: 6, offset: Offset(0, 3)),
      ]),
      child: Row(
        children: [
          Expanded(child: _toggleButton(title: "Today's Food", isSelected: _isTodaySelected, onTap: () => setState(() => _isTodaySelected = true))),
          const SizedBox(width: 8),
          Expanded(
            child: _toggleButton(
              title: "Browse Food",
              isSelected: !_isTodaySelected,
              onTap: () async {
                setState(() => _isTodaySelected = false);
                final result = await Navigator.push(context, MaterialPageRoute(builder: (_) => MealMenuPage()));
                if (result == null) {
                  setState(() => _isTodaySelected = true);
                }
                // Optionally refresh logs after adding food
                if (result == true) {
                  ref.read(mealLogsProvider.notifier).loadInitialLogs();
                  ref.refresh(todayNutrientProvider);
                }
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _toggleButton({required String title, required bool isSelected, required VoidCallback onTap}) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        height: 44,
        decoration: BoxDecoration(color: isSelected ? AppTheme.primaryColor : Colors.grey.shade200, borderRadius: BorderRadius.circular(12)),
        alignment: Alignment.center,
        child: Text(title, style: TextStyle(color: isSelected ? Colors.white : Colors.grey.shade700, fontWeight: FontWeight.w600, fontSize: 14)),
      ),
    );
  }

  Widget _buildEmptyUI({int? index}) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(_getMessageOfMealType(index: index), textAlign: TextAlign.center, style: AppTheme.title16),
            const SizedBox(height: 10),
            Image.asset(_getImageOfMealType(index: index), width: 200, fit: BoxFit.contain),
          ],
        ),
      ),
    );
  }

  String _getMessageOfMealType({int? index}) {
    switch (index) {
      case 1: return HeartThriveStrings.noMealBreakFastSectionMsg;
      case 2: return HeartThriveStrings.noMealLunchSectionMsg;
      case 3: return HeartThriveStrings.noMealSnacksSectionMsg;
      case 4: return HeartThriveStrings.noMealDinnerSectionMsg;
      default: return HeartThriveStrings.noMealAllSectionMsg;
    }
  }

  String _getImageOfMealType({int? index}) {
    switch (index) {
      case 1: return "lib/assets/default_breakfast.png";
      case 2: return "lib/assets/default_lunch_bg.png";
      case 3: return "lib/assets/default_snacks.png";
      case 4: return "lib/assets/default_dinner.png";
      default: return "lib/assets/ss-removebg-preview 1.png";
    }
  }
}

//DailyMealIntakeCard
class DailyMealIntakeCard extends StatefulWidget {
  List<Nutrients>? nutrients;
  DailyMealIntakeCard({super.key,this.nutrients});

  @override
  State<DailyMealIntakeCard> createState() => _DailyMealIntakeCardState();
}

class _DailyMealIntakeCardState extends State<DailyMealIntakeCard> {
  bool _expanded = true;
  String getAmountWithUnit(List<Nutrients> nutrients, String name) {
    final n = nutrients.firstWhere(
          (e) => e.name?.toLowerCase() == name.toLowerCase(),
      orElse: () => Nutrients(
        name: name,
        amount: 0,
        minValue: 0,
        maxValue: 0,
        unitName: '',
      ),
    );

    return '${n.amount?.toStringAsFixed(2)} ${n.unitName}';
  }
  String getAmount(List<Nutrients> nutrients, String name) {
    final n = nutrients.firstWhere(
          (e) => e.name?.toLowerCase() == name.toLowerCase(),
      orElse: () => Nutrients(
        name: name,
        amount: 0,
        minValue: 0,
        maxValue: 0,
        unitName: '',
      ),
    );

    return '${n.amount?.toStringAsFixed(2)}';
  }
  @override
  Widget build(BuildContext context) {
    final String? calories = getAmountWithUnit(widget.nutrients!, 'Calories');
    final String? sodium   = getAmountWithUnit(widget.nutrients!, 'Sodium');
    final String? carbs   = getAmount(widget.nutrients!, 'Carbohydrates');
    final String? fat   = getAmount(widget.nutrients!, 'Fat');
    final String? protein   = getAmount(widget.nutrients!, 'Protein');
    final String? sodiumConsumed   = getAmount(widget.nutrients!, 'Sodium');
    final double consumedSodium = double.parse(sodiumConsumed!);
    final double consumedCarbs = double.parse(carbs!);
    final double consumedFat = double.parse(fat!);
    final double consumedProtein = double.parse(protein!);
    return Center(
      child: ConstrainedBox(
        constraints: const BoxConstraints(
          minWidth: 300,
          maxWidth: 600,
        ),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              /// Header
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Text(
                    "Daily Meal Intake",
                    style:
                    TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                  ),
                  Text(
                    calories!,
                    style:
                    const TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
                  ),
                ],
              ),

              const SizedBox(height: 12),

              /// Progress info row
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _InfoColumn(
                      value: sodium!, label: "Consumed"),

                  /// Middle column with constrained progress bar
                  Column(
                    children: [
                      SizedBox(
                        width: 140, // ✅ constrain width to avoid layout issue
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(8),
                          child: LinearProgressIndicator(
                            minHeight: 8,
                            value: consumedSodium/2500,
                            backgroundColor: Colors.grey.shade300,
                            valueColor: const AlwaysStoppedAnimation(
                                AppTheme.primaryColor
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(height: 6),
                      _InfoColumn(
                        value: sodiumStatus(consumedSodium),
                        label: "",
                        valueColor: AppTheme.primaryColor,
                      ),
                    ],
                  ),

                  const _InfoColumn(value: "2,500 mg", label: "Target"),
                ],
              ),

              const SizedBox(height: 12),

              /// Show More / Less
              InkWell(
                onTap: () {
                  setState(() => _expanded = !_expanded);
                },
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Container(
                      width: 24,
                      height: 24,
                      decoration: const BoxDecoration(
                        color: Color(0xFF95020A),
                        shape: BoxShape.circle,
                      ),
                      child: Icon(
                        _expanded ? Icons.keyboard_arrow_up : Icons.keyboard_arrow_down,
                        color: Colors.white,
                        size: 20,
                      ),
                    ),
                    const SizedBox(width: 4),
                    Text(
                      _expanded ? "Less Info" : "More Info",
                      style: const TextStyle(
                        color: AppTheme.primaryColor,
                        fontWeight: FontWeight.normal,
                      ),
                    ),
                  ],
                ),
              ),

              Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  if (_expanded) ...[
                    const SizedBox(height: 16),

                    /// Nutrients
                    _NutrientBar(
                      title: "Carbs",
                      value: "$carbs / 250g",
                      consumedValue: consumedCarbs,
                      targetedValue: 250,
                      color: Colors.orange,
                      progress: 0.9,
                    ),
                    const SizedBox(height: 10),
                    _NutrientBar(
                      title: "Proteins",
                      value: "$protein / 75g",
                      consumedValue: consumedProtein,
                      targetedValue: 75,
                      color: Colors.indigo,
                      progress: 0.85,
                    ),
                    const SizedBox(height: 10),
                    _NutrientBar(
                      title: "Fats",
                      value: "$fat / 60g",
                      consumedValue: consumedFat,
                      targetedValue: 60,
                      color: Colors.yellow.shade700,
                      progress: 0.95,
                    ),
                  ],
                ],
              )
            ],
          ),
        ),
      ),
    );
  }
  String sodiumStatus(double consumedSodium) {
    const double limit = 2500;

    if (consumedSodium > limit) {
      final exceeded = consumedSodium - limit;
      return "${exceeded.toStringAsFixed(2)} mg limit\nexceeded";
    } else {
      final left = limit - consumedSodium;
      return "${left.toStringAsFixed(2)} mg left";
    }
  }


}
/// Info column widget
class _InfoColumn extends StatelessWidget {
  final String value;
  final String label;
  final Color? valueColor;

  const _InfoColumn({
    required this.value,
    required this.label,
    this.valueColor,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Text(
          value,
          textAlign: TextAlign.center,
          style: TextStyle(
            fontWeight: FontWeight.bold,
            color: valueColor ?? Colors.black,
          ),
        ),
        if (label.isNotEmpty)
          Text(
            label,
            style: TextStyle(fontSize: 12, color: Colors.grey.shade600),
          ),
      ],
    );
  }
}

/// Nutrient progress bar widget
class _NutrientBar extends StatelessWidget {
  final String title;
  final double consumedValue;
  final double targetedValue;
  final String value;
  final Color color;
  final double progress;

  const _NutrientBar({
    required this.title,
    required this.consumedValue,
    required this.targetedValue,
    required this.value,
    required this.color,
    required this.progress,
  });

  @override
  Widget build(BuildContext context) {
    final double progressValue = consumedValue/targetedValue;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.center,
      mainAxisSize: MainAxisSize.min,
      children: [
        // Title
        Text(
          title,
          style: const TextStyle(
            fontSize: 14,
            fontWeight: FontWeight.w600,
          ),
        ),
        const SizedBox(height: 6),
        // Progress bar
        SizedBox(
          width: deviceWidth(context)> 390?120:80,
          child: ClipRRect(
            borderRadius: BorderRadius.circular(10),
            child: LinearProgressIndicator(
              minHeight: 8,
              value: progressValue,
              backgroundColor: Colors.grey.shade300,
              valueColor: AlwaysStoppedAnimation<Color>(color),
            ),
          ),
        ),
        const SizedBox(height: 6),
        // Value
        Text(
          value,
          style: const TextStyle(
            fontSize: 13,
            fontWeight: FontWeight.w500,
            color: Colors.black87,
          ),
        ),
      ],
    );
  }
}

// user food card


class FoodNutrientsCard extends StatelessWidget {
  FoodLogEntry? foodLogEntry;
  FoodNutrientsCard({super.key,this.foodLogEntry});

  @override
  Widget build(BuildContext context) {
    List<ActualNutrientIntake> actualNutrientIntakes = foodLogEntry!.actualNutrientIntakes;
    String? calories= actualNutrientIntakes.valueOf("Calories");
    String? sodium= actualNutrientIntakes.valueOf("Sodium");
    String? carbs= actualNutrientIntakes.valueOf("Carbohydrates");
    String? fat= actualNutrientIntakes.valueOf("Fat");
    String? protein= actualNutrientIntakes.valueOf("Protein");
    double? dcalories= actualNutrientIntakes.valueOfQuantity("Calories");
    double? dsodium= actualNutrientIntakes.valueOfQuantity("Sodium");
    double? dcarbs= actualNutrientIntakes.valueOfQuantity("Carbohydrates");
    double? dfat= actualNutrientIntakes.valueOfQuantity("Fat");
    double? dprotein= actualNutrientIntakes.valueOfQuantity("Protein");
    return LayoutBuilder(
      builder: (context, constraints) {
        final width = constraints.maxWidth < 300 ? 300.0 : constraints.maxWidth;

        return Center(
          child: ConstrainedBox(
            constraints: BoxConstraints(
              minWidth: 300,
              maxWidth: width,
            ),
            child: Card(
              elevation: 3,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
              child: Padding(
                padding: const EdgeInsets.all(12),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  // mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    /// 🔹 Top Row
                    Row(
                      children: [
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children:  [
                              Row(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Expanded(
                                    flex: 8,
                                    child: Text(
                                      foodLogEntry!.foodItemWithNutrients!.description!,
                                      style: AppTheme.title14,
                                    ),
                                  ),
                                  Expanded(
                                    flex: 1,
                                    child: Container(
                                      width: 25,
                                      height: 25,
                                      decoration: BoxDecoration(
                                        shape: BoxShape.circle,
                                        border: Border.all(color: AppTheme.primaryColor, width: 1),
                                      ),
                                      child: Center(
                                        child: Image.asset(
                                          _getImageOfMealType(index: foodLogEntry!.mealType!.id),
                                          height: 15,
                                        ),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                              SizedBox(height: 8),
                              Text(
                                calories,
                                style: AppTheme.title12,
                              ),
                            ],
                          ),
                        ),


                        //Image.asset(_getImageOfMealType(index: foodLogEntry!.mealType!.id),height: 30,),
                        const SizedBox(width: 8),
                        IconButton(onPressed: () async {
                          final editData = MealEditData(
                            id: foodLogEntry!.id!,
                            name: foodLogEntry!.foodItemWithNutrients!.description!,
                            quantity: foodLogEntry!.quantity!,
                            servingUnit: foodLogEntry!.foodItemWithNutrients!.servingUnit,
                            calories: dcalories,
                            sodium: dsodium,
                            carbs: dcarbs,
                            protein: dprotein,
                            fats: dfat,
                            mealTypeId: foodLogEntry!.mealType!.id!,
                          );

                          print("➡️ Passing to AddMealPage:");
                          print(editData.name); // 👈 This prints clean JSON-like output

                          final result = await AppRouter.navigateToAddMeal(
                            context,
                            editData: editData,
                            isEditMode: true,
                          );
                        }, icon: Icon(Icons.edit, color: AppTheme.primaryColor)),
                        const SizedBox(width: 8),

                        Consumer(
                          builder: (context, ref, _) {
                            return IconButton(
                              icon: const Icon(Icons.delete, color: AppTheme.primaryColor),
                              onPressed: () {
                                _showDeleteMealLogDialog(
                                  context,
                                  foodLogEntry!.id!,
                                  foodLogEntry!.foodItemWithNutrients!.description!,
                                  ref
                                );
                              },
                            );
                          },
                        ),

                      ],
                    ),
                    const Divider(
                      color: Colors.black12,
                      thickness: 1,
                    ),
                    /// 🔹 Nutrients Grid
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Expanded(
                          child: _NutrientItem(
                            color: AppTheme.primaryColor,
                            label: "Sodium ($sodium)",
                          ),
                        ),
                        // Spacer(),
                        Expanded(
                          child: _NutrientItem(
                            color: Colors.orange,
                            label: "Carbs ($carbs)",
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 8),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Expanded(
                          child: _NutrientItem(
                            color: Colors.blueAccent,
                            label: "Proteins ($protein)",
                          ),
                        ),
                        //Spacer(),
                        Expanded(
                          child: _NutrientItem(
                            color: Colors.yellow,
                            label: "Fats ($fat)",
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ),
        );
      },
    );
  }

  static Widget _iconCircle(IconData icon) {
    return Container(
      padding: const EdgeInsets.all(6),
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        border: Border.all(color: Colors.redAccent),
      ),
      child: Icon(icon, size: 16, color: Colors.redAccent),
    );
  }
  String _getImageOfMealType({int? index}) {
    switch (index) {
      case 21:
        return "lib/assets/breakfast.png";
      case 22:
        return "lib/assets/Lunch.png";
      case 23:
        return "lib/assets/snacks.png";
      case 24:
        return "lib/assets/dinner.png";
      default:
        return "lib/assets/All Meal.png";
    }
  }
  // Delete Today Meal
  void _showDeleteMealLogDialog(
      BuildContext context,
      int mealLogId,
      String mealName,
      ref
      ) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (dialogContext) {
        bool isDeleting = false;

        return StatefulBuilder(
          builder: (context, setState) {
            return Dialog(
              backgroundColor: Colors.transparent,
              child: Container(
                padding: const EdgeInsets.all(24),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(16),
                ),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Container(
                      width: 60,
                      height: 60,
                      decoration: BoxDecoration(
                        color: Colors.red.withOpacity(0.1),
                        shape: BoxShape.circle,
                      ),
                      child: const Icon(
                        Icons.delete,
                        color: AppTheme.primaryColor,
                        size: 30,
                      ),
                    ),
                    const SizedBox(height: 16),
                    Text(
                      'Are you sure you want to delete "$mealName"?',
                      textAlign: TextAlign.center,
                      style: const TextStyle(fontSize: 16),
                    ),
                    const SizedBox(height: 24),
                    Row(
                      children: [
                        Expanded(
                          child: OutlinedButton(
                            onPressed:
                            isDeleting ? null : () => Navigator.pop(dialogContext),
                            child: const Text('Cancel'),
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: ElevatedButton(
                            onPressed: isDeleting
                                ? null
                                : () async {
                              setState(() => isDeleting = true);

                              final success =
                              await MealService.deleteMealLog(mealLogId);

                              if (success) {
                                Navigator.pop(dialogContext);

                                // ✅ RIVERPOD REFRESH (THIS IS THE FIX)

                                _showMealDeletedSuccess(context, mealName,ref);
                              } else {
                                setState(() => isDeleting = false);
                                ScaffoldMessenger.of(context).showSnackBar(
                                  const SnackBar(
                                    content: Text('Failed to delete meal.'),
                                  ),
                                );
                              }
                            },
                            style: ElevatedButton.styleFrom(
                              backgroundColor: AppTheme.primaryColor,
                            ),
                            child: isDeleting
                                ? const SizedBox(
                              height: 20,
                              width: 20,
                              child: CircularProgressIndicator(
                                strokeWidth: 2,
                                color: Colors.white,
                              ),
                            )
                                : const Text('Delete'),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            );
          },
        );
      },
    );
  }

  // Delete Success Message
  void _showMealDeletedSuccess(BuildContext context, String mealName,ref) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (BuildContext context) {
        return Dialog(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16.0),
          ),
          backgroundColor: Colors.white,
          child: Padding(
            padding: const EdgeInsets.all(24.0),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  width: 80,
                  height: 80,
                  child: Image.asset(
                    'lib/assets/Check Mark.png',
                  ),
                ),
                const SizedBox(height: 16),
                Text(
                  '"$mealName" deleted successfully!',
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                      color: Color(0xFF6F6C90)
                  ),
                ),
                const SizedBox(height: 24),
                SizedBox(
                  width: 100,
                  child: ElevatedButton(
                    onPressed: () {
                      Navigator.pop(context);
                      _refreshMealRelatedProviders(ref);
                    },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: AppTheme.primaryColor,
                      foregroundColor: Colors.white,
                      padding: const EdgeInsets.symmetric(vertical: 12),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(20),
                      ),
                    ),
                    child: const Text('OK',style: AppTheme.whiteTitle14,),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  void _refreshMealRelatedProviders(ref) {
    ref.invalidate(mealLogsProvider);
    ref.invalidate(todayNutrientProvider);
    ref.invalidate(nutrientSummaryProvider);
    ref.invalidate(nutrientSummaryByMealTypeProvider);
  }

}

class _NutrientItem extends StatelessWidget {
  final Color color;
  final String label;

  const _NutrientItem({
    required this.color,
    required this.label,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Container(
          width: 10,
          height: 10,
          decoration: BoxDecoration(
            color: color,
            shape: BoxShape.circle,
          ),
        ),
        const SizedBox(width: 6),
        Flexible(
          child: Text(
            label,
            style: deviceWidth(context)>390? AppTheme.title12:AppTheme.title10,
            overflow: TextOverflow.ellipsis,
          ),
        ),
      ],
    );
  }
}
// Utility
extension NutrientUtils on List<ActualNutrientIntake> {
  String valueOf(String name) {
    final item = firstWhere(
          (e) => (e.nutrientName ?? '').toLowerCase() == name.toLowerCase(),
      orElse: () => ActualNutrientIntake(quantity: 0, unitType: ''),
    );

    return "${(item.quantity ?? 0).toStringAsFixed(2)} ${item.unitType ?? ''}";
  }
}
extension NutrientUtilsDouble on List<ActualNutrientIntake> {
  double valueOfQuantity(String name) {
    final item = firstWhere(
          (e) => (e.nutrientName ?? '').toLowerCase() == name.toLowerCase(),
      orElse: () => ActualNutrientIntake(quantity: 0),
    );

    return item.quantity ?? 0.0;
  }
}



