import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:heart_thrive/pages/meal-sodium/user_today_food.dart';
import 'package:heart_thrive/routes/app_router.dart';

import '../../constants/ui_constants.dart';
import '../../models/meal/food/meal_nutrient_summary.dart';
import '../../models/meal/food/nutrients_model.dart';
import '../../providers/meal/meal_sodium_provider.dart';
import '../../theme/app_theme.dart';

class SodiumHomePageSummary extends ConsumerStatefulWidget {
  const SodiumHomePageSummary({super.key});

  @override
  ConsumerState<SodiumHomePageSummary> createState() =>
      _SodiumHomePageSummaryState();
}

class _SodiumHomePageSummaryState
    extends ConsumerState<SodiumHomePageSummary> {
  bool _showMoreInfo = false;

  // -------------------------------------------------------------
  // Get sodium consumed for a given meal safely
  // -------------------------------------------------------------
  double _getMealSodium(
      NutrientSummaryResponse response,
      String mealName,
      ) {
    final meal = response.summaries.firstWhere(
          (e) => e.mealType.name.toLowerCase() == mealName.toLowerCase(),
      orElse: () => MealTypeNutrientSummary(
        mealType: MealType(
          id: 0,
          uuid: '',
          name: mealName,
          description: '',
          active: false,
        ),
        nutrients: const [],
      ),
    );

    final sodium = meal.nutrients.firstWhere(
          (n) => n.name.toLowerCase() == 'sodium',
      orElse: () => Nutrients(
        name: 'Sodium',
        amount: 0,
        minValue: 0,
        maxValue: 0,
        unitName: 'mg',
      ),
    );

    return sodium.amount;
  }

  Widget _mealTab(
      NutrientSummaryResponse response,
      String meal,
      int target,
      Color color,
      ) {
    return MealProgressTab(
      title: meal,
      consumed: _getMealSodium(response, meal),
      target: target,
      color: color,
    );
  }

  @override
  Widget build(BuildContext context) {
    final nutrientAsync = ref.watch(todayNutrientProvider);
    final mealSummaryAsync = ref.watch(nutrientSummaryByMealTypeProvider);

    return Container(
      padding: const EdgeInsets.all(8),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.08),
            blurRadius: 10,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // ---------------- Header ----------------
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Text(
                "Sodium (mg)",
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
              GestureDetector(
                onTap: (){
                  final route = MaterialPageRoute(
                      builder: (BuildContext context) {
                        return MealLogsPage();
                      });

                  Navigator.push(context, route);
                },
                child: Row(
                  children: [
                    const Text(
                      "Add New",
                      style: TextStyle(
                        color: AppTheme.primaryColor,
                        fontWeight: FontWeight.w500,
                        fontSize: 14,
                      ),
                    ),
                    const SizedBox(width: 4),
                    Container(
                      width: 20,
                      height: 20,
                      decoration: const BoxDecoration(
                          color: Color(0xFF95020A), shape: BoxShape.circle),
                      child:
                      const Icon(Icons.add, color: Colors.white, size: 14),
                    ),
                  ],
                ),
              ),
            ],
          ),

          const SizedBox(height: 12),

          // ---------------- Overall Summary ----------------
          nutrientAsync.when(
            loading: () => const SizedBox(
              height: 120,
              child: Center(child: CircularProgressIndicator()),
            ),
            error: (e, _) => Text("Error: $e"),
            data: (nutrients) =>
                SodiumNutrientSummary(nutrients: nutrients),
          ),

          const SizedBox(height: 16),

          // ---------------- More / Less Toggle ----------------
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              GestureDetector(
                onTap: () =>
                    setState(() => _showMoreInfo = !_showMoreInfo),
                child: Row(
                  children: [
                    Container(
                      width: 20,
                      height: 20,
                      decoration: const BoxDecoration(
                        color: AppTheme.primaryColor,
                        shape: BoxShape.circle,
                      ),
                      child: Icon(
                        _showMoreInfo ? Icons.keyboard_arrow_up : Icons.keyboard_arrow_down,
                        color: Colors.white,
                        size: 16,
                      ),
                    ),
                    const SizedBox(width: 4),
                    Text(
                      _showMoreInfo ? "Less Info" : "More Info",
                      style: const TextStyle(
                        color: Color(0xFF8B0000),
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ],
                ),
              ),
              GestureDetector(
                onTap: (){
                  AppRouter.navigateToSodiumIntakeOverview(context);
                },
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    Image.asset(
                      "lib/assets/dash.png",
                      width: deviceWidth(context) > 360? 22:16,
                      height: deviceWidth(context) > 360? 22:16,
                      color: AppTheme.primaryColor,
                    ),
                    const SizedBox(width: 4),
                    Text(
                      "Dashboard",
                      style: deviceWidth(context) > 360? AppTheme.body14.copyWith(
                        color: AppTheme.primaryColor,
                      ):AppTheme.title12.copyWith(
                        color: AppTheme.primaryColor,
                      ),)
                  ],
                ),
              ),
            ],
          ),

          // ---------------- Meal-wise Summary ----------------
          AnimatedCrossFade(
            duration: const Duration(milliseconds: 250),
            crossFadeState: _showMoreInfo
                ? CrossFadeState.showFirst
                : CrossFadeState.showSecond,
            firstChild: mealSummaryAsync.when(
              loading: () => const Padding(
                padding: EdgeInsets.all(16),
                child: CircularProgressIndicator(),
              ),
              error: (e, _) => Text("Error: $e"),
              data: (summary) {
                if (summary.summaries.isEmpty) {
                  return const Padding(
                    padding: EdgeInsets.all(16),
                    child: Text(
                      "No meal-wise sodium data available",
                      style: TextStyle(color: Colors.grey),
                    ),
                  );
                }

                return Padding(
                  padding: const EdgeInsets.only(top: 16),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      _mealTab(summary, "Breakfast", 700, Colors.orange),
                      _mealTab(summary, "Lunch", 700, Colors.blue),
                      _mealTab(summary, "Snacks", 400, Colors.purple),
                      _mealTab(summary, "Dinner", 700, Colors.indigo),
                    ],
                  ),
                );
              },
            ),
            secondChild: const SizedBox.shrink(),
          ),
        ],
      ),
    );
  }
}

class SodiumNutrientSummary extends StatelessWidget {
  final List<Nutrients> nutrients;
  const SodiumNutrientSummary({super.key, required this.nutrients});

  double _getAmount(String name) {
    return nutrients
        .firstWhere(
          (e) => e.name?.toLowerCase() == name.toLowerCase(),
      orElse: () => Nutrients(
        name: name,
        amount: 0,
        minValue: 0,
        maxValue: 0,
        unitName: 'mg',
      ),
    )
        .amount;
  }

  @override
  Widget build(BuildContext context) {
    const double target = 2500;
    final consumed = _getAmount('Sodium');
    final double progress = (consumed / target).clamp(0, 1);

    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        _InfoColumn(value: "${consumed.toStringAsFixed(2)} mg", label: "Consumed"),
        Column(
          children: [
            SizedBox(
              width: 140,
              child: ClipRRect(
                borderRadius: BorderRadius.circular(8),
                child: LinearProgressIndicator(
                  value: progress,
                  minHeight: 8,
                  backgroundColor: Colors.grey.shade300,
                  valueColor:
                  const AlwaysStoppedAnimation(AppTheme.primaryColor),
                ),
              ),
            ),
            const SizedBox(height: 6),
            Text(
              consumed > target
                  ? "${(consumed - target).toStringAsFixed(2)} mg limit exceeded"
                  : "${(target - consumed).toStringAsFixed(2)} mg left",
              style: const TextStyle(
                  fontSize: 12, fontWeight: FontWeight.w600),
            ),
          ],
        ),
        const _InfoColumn(value: "2,500 mg", label: "Target"),
      ],
    );
  }
}

class MealProgressTab extends StatelessWidget {
  final String title;
  final double consumed;
  final int target;
  final Color color;

  const MealProgressTab({
    super.key,
    required this.title,
    required this.consumed,
    required this.target,
    required this.color,
  });

  @override
  Widget build(BuildContext context) {
    final double progress = target == 0 ? 0 : (consumed / target).clamp(0, 1);

    return Column(
      children: [
        Text(title, style: const TextStyle(fontWeight: FontWeight.w600)),
        const SizedBox(height: 6),
        SizedBox(
          width: 60,
          child: ClipRRect(
            borderRadius: BorderRadius.circular(4),
            child: LinearProgressIndicator(
              value: progress,
              minHeight: 6,
              backgroundColor: Colors.grey.shade300,
              valueColor: AlwaysStoppedAnimation(color),
            ),
          ),
        ),
        const SizedBox(height: 6),
        Text(
          "${consumed.toStringAsFixed(2)} / $target",
          style: const TextStyle(fontSize: 12, color: Colors.grey),
        ),
      ],
    );
  }
}
class _InfoColumn extends StatelessWidget {
  final String value;
  final String label;

  const _InfoColumn({
    required this.value,
    required this.label,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Text(value,
            style: const TextStyle(fontWeight: FontWeight.bold)),
        if (label.isNotEmpty)
          Text(label,
              style:
              TextStyle(fontSize: 12, color: Colors.grey.shade600)),
      ],
    );
  }
}
