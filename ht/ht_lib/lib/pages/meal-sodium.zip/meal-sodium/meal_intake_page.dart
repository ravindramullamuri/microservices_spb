import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:http/http.dart' as http;
import 'package:intl/intl.dart';

import '../../providers/token_provider.dart';
import '../../theme/app_theme.dart';

/// ======================= ENUM & CONSTANTS =======================

enum MealType { all, breakfast, lunch, snacks, dinner }

const Map<MealType, String> mealTypeIcons = {
  MealType.all: "lib/assets/meal/all_meal_rounded_border.png",
  MealType.breakfast: "lib/assets/meal/breakfast_rounded_border.png",
  MealType.lunch: "lib/assets/meal/lunch_rounded_border.png",
  MealType.snacks: "lib/assets/meal/snacks_rounded_border.png",
  MealType.dinner: "lib/assets/meal/dinner_rounded_border.png",
};

const Map<MealType, String> mealTypeLabels = {
  MealType.all: 'All Meal',
  MealType.breakfast: 'Breakfast',
  MealType.lunch: 'Lunch',
  MealType.snacks: 'Snacks',
  MealType.dinner: 'Dinner',
};

final List<MealType> mealTypeOrder = [
  MealType.all,
  MealType.breakfast,
  MealType.lunch,
  MealType.snacks,
  MealType.dinner,
];

/// ======================= MODELS =======================
// (All models remain unchanged – same as before)

class Nutrient {
  final String name;
  final double amount;
  final double maxValue;
  final String unit;

  Nutrient({
    required this.name,
    required this.amount,
    required this.maxValue,
    required this.unit,
  });

  factory Nutrient.fromJson(Map<String, dynamic> json) {
    return Nutrient(
      name: json['name'] as String,
      amount: (json['amount'] as num).toDouble(),
      maxValue: (json['maxValue'] as num).toDouble(),
      unit: json['unitName'] as String,
    );
  }
}

class NutrientSummaryResponse {
  final List<Nutrient> nutrients;
  NutrientSummaryResponse({required this.nutrients});

  factory NutrientSummaryResponse.fromJson(Map<String, dynamic> json) {
    return NutrientSummaryResponse(
      nutrients: (json['nutrients'] as List)
          .map((e) => Nutrient.fromJson(e as Map<String, dynamic>))
          .toList(),
    );
  }

  Nutrient? getByName(String name) {
    try {
      return nutrients.firstWhere((n) => n.name == name);
    } catch (_) {
      return null;
    }
  }
}

class MealTypeInfo {
  final String name;
  MealTypeInfo({required this.name});
  factory MealTypeInfo.fromJson(Map<String, dynamic> json) =>
      MealTypeInfo(name: json['name'] as String);
}

class FoodItem {
  final String description;
  FoodItem({required this.description});
  factory FoodItem.fromJson(Map<String, dynamic> json) =>
      FoodItem(description: json['description'] as String);
}

class ActualNutrientIntake {
  final String nutrientName;
  final double quantity;
  final String unitType;

  ActualNutrientIntake({
    required this.nutrientName,
    required this.quantity,
    required this.unitType,
  });

  factory ActualNutrientIntake.fromJson(Map<String, dynamic> json) {
    return ActualNutrientIntake(
      nutrientName: json['nutrientName'] as String,
      quantity: (json['quantity'] as num).toDouble(),
      unitType: json['unitType'] as String,
    );
  }
}

class MealLog {
  final String title;
  final String? quantity;
  final String mealName;
  final double calories;
  final double sodium;
  final double carbs;
  final double protein;
  final double fats;

  MealLog({
    required this.title,
    this.quantity,
    required this.mealName,
    required this.calories,
    required this.sodium,
    required this.carbs,
    required this.protein,
    required this.fats,
  });

  factory MealLog.fromJson(Map<String, dynamic> json) {
    final foodItem = FoodItem.fromJson(json['foodItemWithNutrients']);
    final mealType = MealTypeInfo.fromJson(json['mealType']);
    final actualIntakes = (json['actualNutrientIntakes'] as List<dynamic>)
        .map((e) => ActualNutrientIntake.fromJson(e as Map<String, dynamic>))
        .toList();

    double getValue(String name) {
      final intake = actualIntakes.firstWhere(
            (i) => i.nutrientName == name,
        orElse: () => ActualNutrientIntake(nutrientName: name, quantity: 0.0, unitType: ''),
      );
      return intake.quantity;
    }

    final rawTitle = foodItem.description;
    final regex = RegExp(r'\s*\((\d+)\)$');
    final match = regex.firstMatch(rawTitle);
    final qty = match != null ? '(${match.group(1)})' : null;
    final cleanTitle = rawTitle.replaceAll(regex, '').trim();

    return MealLog(
      title: cleanTitle,
      quantity: qty,
      mealName: mealType.name,
      calories: getValue('Calories'),
      sodium: getValue('Sodium'),
      carbs: getValue('Carbohydrates'),
      protein: getValue('Protein'),
      fats: getValue('Fat'),
    );
  }
}

class MealLogsResponse {
  final List<MealLog> content;
  MealLogsResponse({required this.content});

  factory MealLogsResponse.fromJson(Map<String, dynamic> json) {
    return MealLogsResponse(
      content: (json['content'] as List)
          .map((e) => MealLog.fromJson(e as Map<String, dynamic>))
          .toList(),
    );
  }
}

/// ======================= API =======================

class MealApi {
  static String _formatDate(DateTime date) {
    return DateFormat('dd-MM-yyyy HH:mm').format(date);
  }

  static Future<NutrientSummaryResponse> fetchSummary({required String token, required DateTime date}) async {
    final from = _formatDate(DateTime(date.year, date.month, date.day, 0, 0));
    final to = _formatDate(DateTime(date.year, date.month, date.day, 23, 59));

    final uri = Uri.parse(
      'https://qaheartthrive.schoolyug.com/api/patient-meal-logs/nutrient-summary'
          '?fromDate=$from'
          '&toDate=$to'
          '&timezone=Asia/Kolkata',
    );

    final res = await http.get(uri, headers: {'Authorization': 'Bearer $token'});
    if (res.statusCode != 200) throw Exception('Summary failed: ${res.statusCode}');
    return NutrientSummaryResponse.fromJson(json.decode(res.body));
  }

  static Future<MealLogsResponse> fetchMeals({
    required String token,
    required DateTime date,
    required int page,
  }) async {
    final from = _formatDate(DateTime(date.year, date.month, date.day, 0, 0));
    final to = _formatDate(DateTime(date.year, date.month, date.day, 23, 59));

    final uri = Uri.parse(
      'https://qaheartthrive.schoolyug.com/api/patient-meal-logs/user-meal-logs'
          '?fromDate=$from'
          '&toDate=$to'
          '&page=$page&size=20',
    );

    final res = await http.get(uri, headers: {'Authorization': 'Bearer $token'});
    if (res.statusCode != 200) throw Exception('Meals failed: ${res.statusCode}');
    return MealLogsResponse.fromJson(json.decode(res.body));
  }
}

/// ======================= PROVIDERS =======================

final todayProvider = Provider<DateTime>((ref) => DateTime.now());

final nutrientSummaryProvider = FutureProvider<NutrientSummaryResponse>((ref) async {
  final token = ref.watch(tokenProvider);
  final today = ref.watch(todayProvider);
  if (token == null || token.isEmpty) throw Exception('Token required');
  return MealApi.fetchSummary(token: token, date: today);
});

class MealState {
  final List<MealLog> meals;
  final MealType selectedMeal;
  final bool showMore;
  final int currentPage;
  final bool hasMore;
  final bool isLoadingMore;

  MealState({
    required this.meals,
    this.selectedMeal = MealType.all,
    this.showMore = false,
    this.currentPage = 0,
    this.hasMore = true,
    this.isLoadingMore = false,
  });

  MealState copyWith({
    List<MealLog>? meals,
    MealType? selectedMeal,
    bool? showMore,
    int? currentPage,
    bool? hasMore,
    bool? isLoadingMore,
  }) {
    return MealState(
      meals: meals ?? this.meals,
      selectedMeal: selectedMeal ?? this.selectedMeal,
      showMore: showMore ?? this.showMore,
      currentPage: currentPage ?? this.currentPage,
      hasMore: hasMore ?? this.hasMore,
      isLoadingMore: isLoadingMore ?? this.isLoadingMore,
    );
  }
}

class MealNotifier extends StateNotifier<AsyncValue<MealState>> {
  final Ref ref;
  late final DateTime today;

  MealNotifier(this.ref) : super(const AsyncLoading()) {
    today = ref.read(todayProvider);
    load(initial: true);
  }

  Future<void> load({bool initial = false}) async {
    if (initial) {
      state = const AsyncLoading();
    }

    try {
      final token = ref.read(tokenProvider);
      if (token == null) throw Exception('Token missing');

      final currentState = state.value ?? MealState(meals: []);
      final page = initial ? 0 : currentState.currentPage;

      final response = await MealApi.fetchMeals(token: token, date: today, page: page);

      final newMeals = response.content;
      final updatedMeals = initial ? newMeals : [...currentState.meals, ...newMeals];

      final hasMore = newMeals.length == 20;

      state = AsyncData(currentState.copyWith(
        meals: updatedMeals,
        currentPage: page + 1,
        hasMore: hasMore,
        isLoadingMore: false,
      ));
    } catch (e, st) {
      state = AsyncError(e, st);
    }
  }

  Future<void> refresh() async {
    await load(initial: true);
  }

  void changeMeal(MealType type) {
    state = state.whenData((s) => s.copyWith(selectedMeal: type));
  }

  void toggleMore() {
    state = state.whenData((s) => s.copyWith(showMore: !s.showMore));
  }

  Future<void> loadMore() async {
    if (state.isLoading || !(state.value?.hasMore ?? true)) return;

    state = AsyncData(state.value!.copyWith(isLoadingMore: true));
    await load(initial: false);
  }
}

final mealProvider = StateNotifierProvider<MealNotifier, AsyncValue<MealState>>(
      (ref) => MealNotifier(ref),
);

/// ======================= MAIN PAGE =======================

class AllMealIntakePage extends ConsumerWidget {
  final int index;

  const AllMealIntakePage({
    super.key,
    this.index = 0,
  });

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final initialMealType = mealTypeOrder[index.clamp(0, 4)];

    ref.listen(mealProvider, (_, next) {
      next.whenData((state) {
        if (state.selectedMeal == MealType.all && state.meals.isNotEmpty) {
          ref.read(mealProvider.notifier).changeMeal(initialMealType);
        }
      });
    });

    final summaryAsync = ref.watch(nutrientSummaryProvider);
    final mealAsync = ref.watch(mealProvider);

    return Scaffold(
      backgroundColor: const Color(0xFFF5F5F5),
      appBar: AppBar(
        backgroundColor: const Color(0xFF8B0000),
        title: const Text('All Meal Intake'),
        actions: const [Icon(Icons.more_vert)],
      ),
      body: summaryAsync.when(
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (err, _) => Center(child: Text('Error: $err')),
        data: (summary) {
          final sodium = summary.getByName('Sodium') ??
              Nutrient(name: 'Sodium', amount: 0, maxValue: 2500, unit: 'mg');
          final calories = summary.getByName('Calories') ??
              Nutrient(name: 'Calories', amount: 0, maxValue: 2500, unit: 'kcal');
          final carbs = summary.getByName('Carbohydrates') ??
              Nutrient(name: 'Carbohydrates', amount: 0, maxValue: 250, unit: 'g');
          final protein = summary.getByName('Protein') ??
              Nutrient(name: 'Protein', amount: 0, maxValue: 75, unit: 'g');
          final fats = summary.getByName('Fat') ??
              Nutrient(name: 'Fat', amount: 0, maxValue: 60, unit: 'g');

          return RefreshIndicator(
            onRefresh: () => ref.read(mealProvider.notifier).refresh(),
            child: mealAsync.when(
              loading: () => const Center(child: CircularProgressIndicator()),
              error: (err, _) => Center(child: Text('Error: $err')),
              data: (mealState) {
                final currentMealType = mealState.selectedMeal == MealType.all
                    ? initialMealType
                    : mealState.selectedMeal;

                final filteredMeals = currentMealType == MealType.all
                    ? mealState.meals
                    : mealState.meals
                    .where((m) => m.mealName.toLowerCase() == currentMealType.name)
                    .toList();

                return Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    children: [
                      _summaryCard(
                        sodium: sodium,
                        calories: calories,
                        carbs: carbs,
                        protein: protein,
                        fats: fats,
                        showMore: mealState.showMore,
                        onToggle: () => ref.read(mealProvider.notifier).toggleMore(),
                      ),
                      const SizedBox(height: 16),
                      _mealTabs(
                        selected: currentMealType,
                        onTap: (t) => ref.read(mealProvider.notifier).changeMeal(t),
                      ),
                      const SizedBox(height: 20),
                      Row(
                        children: [
                          Expanded(
                            child: ElevatedButton(
                              onPressed: () => debugPrint("Today's Food"),
                              style: ElevatedButton.styleFrom(
                                backgroundColor: const Color(0xFF8B0000),
                                foregroundColor: Colors.white,
                                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                              ),
                              child: const Text("Today's Food"),
                            ),
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: OutlinedButton(
                              onPressed: () => debugPrint("Browse Food"),
                              style: OutlinedButton.styleFrom(
                                side: const BorderSide(color: Color(0xFF8B0000)),
                                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                              ),
                              child: const Text("Browse Food", style: TextStyle(color: Color(0xFF8B0000))),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 20),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            mealTypeLabels[currentMealType]!,
                            style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                          ),
                          Text(
                            'Sodium ${sodium.amount.toStringAsFixed(0)} mg/${sodium.maxValue.toStringAsFixed(0)} mg',
                            style: const TextStyle(fontSize: 14),
                          ),
                        ],
                      ),
                      const SizedBox(height: 12),
                      Expanded(
                        child: ListView.builder(
                          physics: const AlwaysScrollableScrollPhysics(), // Important for pull-to-refresh
                          itemCount: filteredMeals.length + (mealState.isLoadingMore ? 1 : 0),
                          itemBuilder: (context, i) {
                            if (i == filteredMeals.length) {
                              if (mealState.hasMore) {
                                ref.read(mealProvider.notifier).loadMore();
                              }
                              return const Padding(
                                padding: EdgeInsets.symmetric(vertical: 16),
                                child: Center(child: CircularProgressIndicator()),
                              );
                            }
                            return _mealCard(filteredMeals[i]);
                          },
                        ),
                      ),
                    ],
                  ),
                );
              },
            ),
          );
        },
      ),
    );
  }

  /// ======================= UI WIDGETS =======================

  Widget _summaryCard({
    required Nutrient sodium,
    required Nutrient calories,
    required Nutrient carbs,
    required Nutrient protein,
    required Nutrient fats,
    required bool showMore,
    required VoidCallback onToggle,
  }) {
    final consumed = sodium.amount;
    final target = sodium.maxValue;
    final left = (target - consumed).clamp(0.0, target);
    final progress = (consumed / target).clamp(0.0, 1.0);

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: _card(),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Text('Daily Meal Intake', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
              Text('${calories.amount.toStringAsFixed(1)} kcal',
                  style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            ],
          ),
          const SizedBox(height: 16),
          Row(
            children: [
              Text('${consumed.toStringAsFixed(1)} mg\nConsumed',
                  style: const TextStyle(fontSize: 14, color: Colors.black54), textAlign: TextAlign.center),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  children: [
                    LinearProgressIndicator(
                      value: progress,
                      minHeight: 10,
                      backgroundColor: Colors.grey.shade300,
                      valueColor: const AlwaysStoppedAnimation(Color(0xFF8B0000)),
                    ),
                    const SizedBox(height: 8),
                    Text('${left.toStringAsFixed(1)} mg left',
                        style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w600)),
                  ],
                ),
              ),
              const SizedBox(width: 12),
              Text('${target.toStringAsFixed(0)} mg\nTarget',
                  style: const TextStyle(fontSize: 14, color: Colors.black54), textAlign: TextAlign.center),
            ],
          ),
          const SizedBox(height: 20),
          GestureDetector(
            onTap: onToggle,
            child: Row(
              children: [
                CircleAvatar(
                  radius: 14,
                  backgroundColor: const Color(0xFF8B0000),
                  child: Icon(showMore ? Icons.keyboard_arrow_up : Icons.keyboard_arrow_down,
                      color: Colors.white, size: 20),
                ),
                const SizedBox(width: 8),
                Text(showMore ? 'Less Info' : 'More Info',
                    style: const TextStyle(color: Color(0xFF8B0000), fontWeight: FontWeight.w600, fontSize: 16)),
              ],
            ),
          ),
          if (showMore) ...[
            const SizedBox(height: 20),
            Row(
              children: const [
                Expanded(child: Text('Carbs', textAlign: TextAlign.center, style: TextStyle(fontSize: 14, fontWeight: FontWeight.w600))),
                Expanded(child: Text('Proteins', textAlign: TextAlign.center, style: TextStyle(fontSize: 14, fontWeight: FontWeight.w600))),
                Expanded(child: Text('Fats', textAlign: TextAlign.center, style: TextStyle(fontSize: 14, fontWeight: FontWeight.w600))),
              ],
            ),
            const SizedBox(height: 10),
            Row(
              children: [
                Expanded(child: _macroProgress(value: carbs.amount, max: carbs.maxValue, color: Colors.orange)),
                const SizedBox(width: 12),
                Expanded(child: _macroProgress(value: protein.amount, max: protein.maxValue, color: Colors.indigo)),
                const SizedBox(width: 12),
                Expanded(child: _macroProgress(value: fats.amount, max: fats.maxValue, color: Colors.amber)),
              ],
            ),
            const SizedBox(height: 8),
            Row(
              children: [
                Expanded(child: Text('${carbs.amount.toStringAsFixed(0)}g / ${carbs.maxValue.toStringAsFixed(0)}g', textAlign: TextAlign.center, style: TextStyle(fontSize: 12))),
                Expanded(child: Text('${protein.amount.toStringAsFixed(0)}g / ${protein.maxValue.toStringAsFixed(0)}g', textAlign: TextAlign.center, style: TextStyle(fontSize: 12))),
                Expanded(child: Text('${fats.amount.toStringAsFixed(0)}g / ${fats.maxValue.toStringAsFixed(0)}g', textAlign: TextAlign.center, style: TextStyle(fontSize: 12))),
              ],
            ),
          ]
        ],
      ),
    );
  }

  Widget _macroProgress({required double value, required double max, required Color color}) {
    final progress = (value / max).clamp(0.0, 1.0);
    return LinearProgressIndicator(
      value: progress,
      minHeight: 8,
      backgroundColor: Colors.grey.shade200,
      valueColor: AlwaysStoppedAnimation(color),
    );
  }

  Widget _mealTabs({
    required MealType selected,
    required ValueChanged<MealType> onTap,
  }) {
    return Container(
      decoration: _card(),
      padding: const EdgeInsets.symmetric(vertical: 12),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: mealTypeOrder.map((type) {
          final active = type == selected;
          return GestureDetector(
            onTap: () => onTap(type),
            child: Column(
              children: [
                Container(
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    boxShadow: active
                        ? null
                        : [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.08),
                        blurRadius: 4,
                        spreadRadius: 0.5,
                        offset: const Offset(0, 2),
                      ),
                    ],
                  ),
                  child: Container(
                    width: 40,
                    height: 40,
                    padding: const EdgeInsets.all(6),
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      border: Border.all(
                        color: active ? AppTheme.primaryColor : Colors.transparent,
                        width: 1,
                      ),
                      color: Colors.white,
                    ),
                    child: Image.asset(
                      mealTypeIcons[type]!,
                      color: AppTheme.primaryColor,
                      fit: BoxFit.contain,
                    ),
                  ),
                ),
                const SizedBox(height: 8),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                  decoration: BoxDecoration(
                    color: active ? AppTheme.primaryColor : Colors.transparent,
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Text(
                    mealTypeLabels[type]!,
                    style: AppTheme.title12.copyWith(
                      color: active ? Colors.white : Colors.black54,
                    ),
                  ),
                ),
              ],
            ),
          );
        }).toList(),
      ),
    );
  }

  Widget _mealCard(MealLog m) {
    final type = mealTypeOrder.firstWhere(
          (e) => e.name.toLowerCase() == m.mealName.toLowerCase(),
      orElse: () => MealType.all,
    );

    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(16),
      decoration: _card(),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 35,
                height: 35,
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  border: Border.all(color: AppTheme.primaryColor, width: 1),
                ),
                child: ClipOval(
                  child: Image.asset(
                    mealTypeIcons[type]!,
                    fit: BoxFit.cover,
                  ),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Text(
                  m.title,
                  style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
                ),
              ),
              if (m.quantity != null)
                Text(m.quantity!, style: const TextStyle(fontSize: 14, color: Colors.black54)),
              const SizedBox(width: 12),
              const Icon(Icons.edit, color: Color(0xFF8B0000)),
              const SizedBox(width: 8),
              const Icon(Icons.delete, color: Color(0xFF8B0000)),
            ],
          ),
          const SizedBox(height: 12),
          Text('${m.calories.toStringAsFixed(0)} kcal', style: const TextStyle(fontSize: 14)),
          const SizedBox(height: 12),
          Row(
            children: [
              _nutrientDot('Sodium', '${m.sodium.toStringAsFixed(0)}mg', Colors.red),
              _nutrientDot('Carbs', '${m.carbs.toStringAsFixed(0)}g', Colors.orange),
              _nutrientDot('Proteins', '${m.protein.toStringAsFixed(0)}g', Colors.indigo),
              _nutrientDot('Fats', '${m.fats.toStringAsFixed(0)}g', Colors.amber),
            ],
          ),
        ],
      ),
    );
  }

  Widget _nutrientDot(String label, String value, Color color) {
    return Expanded(
      child: Row(
        children: [
          Container(width: 8, height: 8, decoration: BoxDecoration(shape: BoxShape.circle, color: color)),
          const SizedBox(width: 8),
          Text('$label ($value)', style: const TextStyle(fontSize: 12)),
        ],
      ),
    );
  }

  BoxDecoration _card() => BoxDecoration(
    color: Colors.white,
    borderRadius: BorderRadius.circular(16),
    boxShadow: [
      BoxShadow(color: Colors.black.withOpacity(0.05), blurRadius: 10, offset: const Offset(0, 4)),
    ],
  );
}