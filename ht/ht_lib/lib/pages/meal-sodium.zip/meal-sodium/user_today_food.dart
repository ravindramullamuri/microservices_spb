import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:heart_thrive/constants/heart_thrive_strings_constants.dart';
import 'package:heart_thrive/constants/ui_constants.dart';
import 'package:http/http.dart' as http;
import 'package:intl/intl.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../../models/meal/edit_meal_model.dart';
import '../../models/meal/food/food_response_model.dart';
import '../../routes/app_router.dart';
import '../../theme/app_theme.dart';
import '../../utils/secure_storage_utils.dart';
import 'browse_food_page.dart' hide Nutrient;


/// =======================
/// UI PAGE
/// =======================
///


class DailyMealIntakeCard extends StatefulWidget {
  List<Nutrient>? nutrients;
   DailyMealIntakeCard({super.key,this.nutrients});

  @override
  State<DailyMealIntakeCard> createState() => _DailyMealIntakeCardState();
}

class _DailyMealIntakeCardState extends State<DailyMealIntakeCard> {
  bool _expanded = true;
  String getAmountWithUnit(List<Nutrient> nutrients, String name) {
    final n = nutrients.firstWhere(
          (e) => e.name?.toLowerCase() == name.toLowerCase(),
      orElse: () => Nutrient(
        name: name,
        amount: 0,
        minValue: 0,
        maxValue: 0,
        unitName: '',
      ),
    );

    return '${n.amount?.toStringAsFixed(2)} ${n.unitName}';
  }
  String getAmount(List<Nutrient> nutrients, String name) {
    final n = nutrients.firstWhere(
          (e) => e.name?.toLowerCase() == name.toLowerCase(),
      orElse: () => Nutrient(
        name: name,
        amount: 0,
        minValue: 0,
        maxValue: 0,
        unitName: '',
      ),
    );

    return '${n.amount?.toStringAsFixed(2)}';
  }
  @override
  Widget build(BuildContext context) {
    final String? calories = getAmountWithUnit(widget.nutrients!, 'Calories');
    final String? sodium   = getAmountWithUnit(widget.nutrients!, 'Sodium');
    final String? carbs   = getAmount(widget.nutrients!, 'Carbohydrates');
    final String? fat   = getAmount(widget.nutrients!, 'Fat');
    final String? protein   = getAmount(widget.nutrients!, 'Protein');
    final String? sodiumConsumed   = getAmount(widget.nutrients!, 'Sodium');
    final double consumedSodium = double.parse(sodiumConsumed!);
    final double consumedCarbs = double.parse(carbs!);
    final double consumedFat = double.parse(fat!);
    final double consumedProtein = double.parse(protein!);
    return Center(
      child: ConstrainedBox(
        constraints: const BoxConstraints(
          minWidth: 300,
          maxWidth: 600,
        ),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              /// Header
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Text(
                    "Daily Meal Intake",
                    style:
                    TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                  ),
                  Text(
                    calories!,
                    style:
                    const TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
                  ),
                ],
              ),

              const SizedBox(height: 12),

              /// Progress info row
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _InfoColumn(
                      value: sodium!, label: "Consumed"),

                  /// Middle column with constrained progress bar
                  Column(
                    children: [
                      SizedBox(
                        width: 140, // ✅ constrain width to avoid layout issue
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(8),
                          child: LinearProgressIndicator(
                            minHeight: 8,
                            value: consumedSodium/2500,
                            backgroundColor: Colors.grey.shade300,
                            valueColor: const AlwaysStoppedAnimation(
                                AppTheme.primaryColor
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(height: 6),
                      _InfoColumn(
                        value: sodiumStatus(consumedSodium),
                        label: "",
                        valueColor: AppTheme.primaryColor,
                      ),
                    ],
                  ),

                  const _InfoColumn(value: "2,500 mg", label: "Target"),
                ],
              ),

              const SizedBox(height: 12),

              /// Show More / Less
              InkWell(
                onTap: () {
                  setState(() => _expanded = !_expanded);
                },
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Container(
                      width: 24,
                      height: 24,
                      decoration: const BoxDecoration(
                        color: Color(0xFF95020A),
                        shape: BoxShape.circle,
                      ),
                      child: Icon(
                        _expanded ? Icons.keyboard_arrow_up : Icons.keyboard_arrow_down,
                        color: Colors.white,
                        size: 20,
                      ),
                    ),
                    const SizedBox(width: 4),
                    Text(
                      _expanded ? "Less Info" : "More Info",
                      style: const TextStyle(
                        color: AppTheme.primaryColor,
                        fontWeight: FontWeight.normal,
                      ),
                    ),
                  ],
                ),
              ),

             Row(
               mainAxisAlignment: MainAxisAlignment.spaceAround,
               children: [
                 if (_expanded) ...[
                   const SizedBox(height: 16),

                   /// Nutrients
                   _NutrientBar(
                     title: "Carbs",
                     value: "$carbs / 250g",
                     consumedValue: consumedCarbs,
                     targetedValue: 250,
                     color: Colors.orange,
                     progress: 0.9,
                   ),
                   const SizedBox(height: 10),
                   _NutrientBar(
                     title: "Proteins",
                     value: "$protein / 75g",
                     consumedValue: consumedProtein,
                     targetedValue: 75,
                     color: Colors.indigo,
                     progress: 0.85,
                   ),
                   const SizedBox(height: 10),
                   _NutrientBar(
                     title: "Fats",
                     value: "$fat / 60g",
                     consumedValue: consumedFat,
                     targetedValue: 60,
                     color: Colors.yellow.shade700,
                     progress: 0.95,
                   ),
                 ],
               ],
             )
            ],
          ),
        ),
      ),
    );
  }
  String sodiumStatus(double consumedSodium) {
    const double limit = 2500;

    if (consumedSodium > limit) {
      final exceeded = consumedSodium - limit;
      return "${exceeded.toStringAsFixed(2)} mg limit\nexceeded";
    } else {
      final left = limit - consumedSodium;
      return "${left.toStringAsFixed(2)} mg left";
    }
  }


}

/// Info column widget
class _InfoColumn extends StatelessWidget {
  final String value;
  final String label;
  final Color? valueColor;

  const _InfoColumn({
    required this.value,
    required this.label,
    this.valueColor,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Text(
          value,
          textAlign: TextAlign.center,
          style: TextStyle(
            fontWeight: FontWeight.bold,
            color: valueColor ?? Colors.black,
          ),
        ),
        if (label.isNotEmpty)
          Text(
            label,
            style: TextStyle(fontSize: 12, color: Colors.grey.shade600),
          ),
      ],
    );
  }
}

/// Nutrient progress bar widget
class _NutrientBar extends StatelessWidget {
  final String title;
  final double consumedValue;
  final double targetedValue;
  final String value;
  final Color color;
  final double progress;

  const _NutrientBar({
    required this.title,
    required this.consumedValue,
    required this.targetedValue,
    required this.value,
    required this.color,
    required this.progress,
  });

  @override
  Widget build(BuildContext context) {
    final double progressValue = consumedValue/targetedValue;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.center,
      mainAxisSize: MainAxisSize.min,
      children: [
        // Title
        Text(
          title,
          style: const TextStyle(
            fontSize: 14,
            fontWeight: FontWeight.w600,
          ),
        ),
        const SizedBox(height: 6),
        // Progress bar
        SizedBox(
          width: deviceWidth(context)> 390?120:80,
          child: ClipRRect(
            borderRadius: BorderRadius.circular(10),
            child: LinearProgressIndicator(
              minHeight: 8,
              value: progressValue,
              backgroundColor: Colors.grey.shade300,
              valueColor: AlwaysStoppedAnimation<Color>(color),
            ),
          ),
        ),
        const SizedBox(height: 6),
        // Value
        Text(
          value,
          style: const TextStyle(
            fontSize: 13,
            fontWeight: FontWeight.w500,
            color: Colors.black87,
          ),
        ),
      ],
    );
  }
}





class MealLogsPage extends StatefulWidget {
  const MealLogsPage({super.key});

  @override
  State<MealLogsPage> createState() => _MealLogsPageState();
}

class _MealLogsPageState extends State<MealLogsPage> {
  final List<FoodLogEntry> _logs = [];
  late List<Nutrient> _nutrients = [];
  final ScrollController _controller = ScrollController();

  int _page = 0;
  final int _size = 20;
  bool _isLoading = false;
  bool _isLast = false;

  /// 🔹 Selected meal index (0 = All)
  int _selectedMealIndex = 0;

  /// 🔹 Meal tabs with index mapping
  final List<Map<String, dynamic>> _mealTabs = [
    {"title": "All Meal", "icon": 'lib/assets/All Meal.png'},
    {"title": "Breakfast", "icon": 'lib/assets/breakfast.png'},
    {"title": "Lunch", "icon": 'lib/assets/Lunch.png'},
    {"title": "Snacks", "icon": 'lib/assets/snacks.png'},
    {"title": "Dinner", "icon": 'lib/assets/dinner.png'},
  ];
  bool _isTodaySelected = true;

  @override
  void initState() {
    super.initState();
    _loadLogs();

    _controller.addListener(() {
      if (_controller.position.pixels >=
          _controller.position.maxScrollExtent - 200 &&
          !_isLoading &&
          !_isLast) {
        _loadLogs();
      }
    });
  }

  /// 🔹 Filter logs based on selected index
  List<FoodLogEntry> get _filteredLogs {
    if (_selectedMealIndex == 0) return _logs;

    final selectedMeal =
    _mealTabs[_selectedMealIndex]["title"].toString().toLowerCase();

    return _logs.where((e) {
      final mealName = e.mealType?.name?.toLowerCase() ?? '';
      return mealName == selectedMeal;
    }).toList();
  }

  /// 🔹 Meal tabs UI
  Widget _buildMealTabs() {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: SizedBox(
        height: 110,
        width: double.infinity,
        child: LayoutBuilder(
          builder: (context, constraints) {
            return Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: List.generate(_mealTabs.length, (index) {
                final tab = _mealTabs[index];
                final bool isSelected = _selectedMealIndex == index;

                return Expanded(
                  child: GestureDetector(
                    onTap: () {
                      setState(() {
                        _selectedMealIndex = index;
                      });
                    },
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        // Icon circle
                        Container(
                          width:  deviceWidth(context)> 390?56:40,
                          height: deviceWidth(context)> 390?56:40,
                          decoration: BoxDecoration(
                            color: Colors.white,
                            shape: BoxShape.circle,
                            border: isSelected
                                ? Border.all(
                              color: AppTheme.primaryColor,
                              width: 1,
                            )
                                : null,
                            boxShadow: const [
                              BoxShadow(
                                color: Colors.black12,
                                blurRadius: 6,
                                offset: Offset(0, 3),
                              ),
                            ],
                          ),
                          child: Center(
                            child: Image.asset(
                              tab["icon"],
                              width: deviceWidth(context)> 390?26:20,
                              color: isSelected
                                  ? AppTheme.primaryColor
                                  : Colors.grey.shade600,
                            ),
                          ),
                        ),
                        const SizedBox(height: 8),
                        // Title
                        isSelected
                            ? Container(
                          width: 80,
                          padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 3),
                          //height: 20,
                          alignment: Alignment.center,
                          decoration: BoxDecoration(
                            color: AppTheme.primaryColor,
                            borderRadius: BorderRadius.circular(18),
                          ),
                          child: Text(
                            tab["title"],
                            style: const TextStyle(
                              fontSize: 12,
                              fontWeight: FontWeight.w600,
                              color: Colors.white,
                            ),
                          ),
                        )
                            : Text(
                          tab["title"],
                          textAlign: TextAlign.center,
                          style: const TextStyle(
                            fontSize: 12,
                            fontWeight: FontWeight.w500,
                            color: Colors.black87,
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              }),
            );
          },
        ),
      ),
    );
  }



  Future<void> _loadLogs() async {
    setState(() => _isLoading = true);
    try {
      final now = DateTime.now();
      final date = DateFormat('dd-MM-yyyy').format(now);

      final fromDate = '$date 00:00';
      final toDate   = '$date 23:59';
      final List<Nutrient> response = await fetchNutrientSummary(
        fromDate: fromDate,
        toDate: toDate,
        timezone: 'Asia/Kolkata',
      );
      setState(() {
        _nutrients = response;
      });
    } catch (e) {
      debugPrint('Error: $e');
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }

    try {
      final response = await fetchMealLogs(page: _page, size: _size);
      setState(() {
        _logs.addAll(response.content);
        _isLast = response.last ?? true;
        _page++;
      });
    } catch (e) {
      debugPrint('Error: $e');
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final logsToShow = _filteredLogs;

    return Scaffold(
      appBar: AppBar(title: const Text('Today Meal Logs')),
      body: Column(
        children: [
          Container(
            margin: const EdgeInsets.symmetric(horizontal: 10.0,vertical: 10),
            padding: const EdgeInsets.all(5.0),
            decoration:  BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(12.0), // rounded corners
              boxShadow: [
                BoxShadow(
                  color: Colors.grey.shade300, // shadow color
                  spreadRadius: 1, // spread
                  blurRadius: 6,   // softness of shadow
                  offset: const Offset(0, 3), // position of shadow (x, y)
                ),
              ],
            ),
            child: DailyMealIntakeCard(
              nutrients: _nutrients,
            ),
          ),
         Expanded(child: Container(
           margin: const EdgeInsets.symmetric(horizontal: 10.0,vertical: 10),
           padding: const EdgeInsets.all(5.0),
           decoration:  BoxDecoration(
             color: Colors.white,
             borderRadius: BorderRadius.circular(12.0), // rounded corners
             boxShadow: [
               BoxShadow(
                 color: Colors.grey.shade300, // shadow color
                 spreadRadius: 1, // spread
                 blurRadius: 6,   // softness of shadow
                 offset: const Offset(0, 3), // position of shadow (x, y)
               ),
             ],
           ),
           child: Column(
             children: [
               _buildFoodToggle(),
               /// 🔹 Meal Tabs Row
               _buildMealTabs(),

               Expanded(
                 child:logsToShow.isNotEmpty? ListView.builder(
                   controller: _controller,
                   itemCount: logsToShow.length + (_isLoading ? 1 : 0),
                   itemBuilder: (context, index) {
                     if (index >= logsToShow.length) {
                       return const Padding(
                         padding: EdgeInsets.all(16),
                         child: Center(child: CircularProgressIndicator()),
                       );
                     }

                     final FoodLogEntry foodLogEntry = logsToShow[index];

                     return Padding(
                       padding: const EdgeInsets.all(8.0),
                       child: FoodNutrientsCard(
                         foodLogEntry: foodLogEntry,
                       ),
                     );
                   },
                 ):_buildEmptyUI(index: _selectedMealIndex),
               ),
             ],
           ),
         ))
        ],
      ),
    );
  }
  Widget _buildEmptyUI({int? index}){
    return Center(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
             Text(
              _getMessageOfMealType(index: index),
              textAlign: TextAlign.center,
              style: AppTheme.title16,
            ),
            const SizedBox(height: 10),
            /// 🔹 Illustration Image
            Image.asset(
              _getImageOfMealType(index: index), // 👈 put your image here
              width: 200,
              fit: BoxFit.contain,
            ),
          ],
        ),
      ),
    );
  }
  // Build Toggle
  Widget _buildFoodToggle() {
    return Container(
      padding: const EdgeInsets.all(6),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: const [
          BoxShadow(
            color: Colors.black12,
            blurRadius: 6,
            offset: Offset(0, 3),
          ),
        ],
      ),
      child: Row(
        children: [
          Expanded(
            child: _toggleButton(
              title: "Today's Food",
              isSelected: _isTodaySelected,
              onTap: () {
                setState(() {
                  _isTodaySelected = true;
                });
              },
            ),
          ),
          const SizedBox(width: 8),
          Expanded(
            child: _toggleButton(
              title: "Browse Food",
              isSelected: !_isTodaySelected,
              onTap: () async {
                setState(() {
                  _isTodaySelected = false;
                });
               final route = MaterialPageRoute(builder: (context)=>MealMenuPage());
                final result = await Navigator.push(context, route);
                print("result @@ $result");
                if(result == null){
                 setState(() {
                   _isTodaySelected = true;
                 });
                }
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _toggleButton({
    required String title,
    required bool isSelected,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        height: 44,
        decoration: BoxDecoration(
          color: isSelected
              ? AppTheme.primaryColor
              : Colors.grey.shade200,
          borderRadius: BorderRadius.circular(12),
        ),
        alignment: Alignment.center,
        child: Text(
          title,
          style: TextStyle(
            color: isSelected ? Colors.white : Colors.grey.shade700,
            fontWeight: FontWeight.w600,
            fontSize: 14,
          ),
        ),
      ),
    );
  }

  String _getMessageOfMealType({int? index}) {
    switch (index) {
      case 1:
        return HeartThriveStrings.noMealBreakFastSectionMsg;
      case 2:
        return HeartThriveStrings.noMealLunchSectionMsg;
      case 3:
        return HeartThriveStrings.noMealSnacksSectionMsg;
      case 4:
        return HeartThriveStrings.noMealDinnerSectionMsg;
      default:
        return HeartThriveStrings.noMealAllSectionMsg;
    }
  }
  String _getImageOfMealType({int? index}) {
    switch (index) {
      case 1:
        return "lib/assets/default_breakfast.png";
      case 2:
        return "lib/assets/default_lunch_bg.png";
      case 3:
        return "lib/assets/default_snacks.png";
      case 4:
        return "lib/assets/default_dinner.png";
      default:
        return "lib/assets/ss-removebg-preview 1.png";
    }
  }

}


// user food card


class FoodNutrientsCard extends StatelessWidget {
  FoodLogEntry? foodLogEntry;
   FoodNutrientsCard({super.key,this.foodLogEntry});

  @override
  Widget build(BuildContext context) {
    List<ActualNutrientIntake> actualNutrientIntakes = foodLogEntry!.actualNutrientIntakes;
    String? calories= actualNutrientIntakes.valueOf("Calories");
    String? sodium= actualNutrientIntakes.valueOf("Sodium");
    String? carbs= actualNutrientIntakes.valueOf("Carbohydrates");
    String? fat= actualNutrientIntakes.valueOf("Fat");
    String? protein= actualNutrientIntakes.valueOf("Protein");
    double? dcalories= actualNutrientIntakes.valueOfQuantity("Calories");
    double? dsodium= actualNutrientIntakes.valueOfQuantity("Sodium");
    double? dcarbs= actualNutrientIntakes.valueOfQuantity("Carbohydrates");
    double? dfat= actualNutrientIntakes.valueOfQuantity("Fat");
    double? dprotein= actualNutrientIntakes.valueOfQuantity("Protein");
    return LayoutBuilder(
      builder: (context, constraints) {
        final width = constraints.maxWidth < 300 ? 300.0 : constraints.maxWidth;

        return Center(
          child: ConstrainedBox(
            constraints: BoxConstraints(
              minWidth: 300,
              maxWidth: width,
            ),
            child: Card(
              elevation: 3,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
              child: Padding(
                padding: const EdgeInsets.all(12),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                 // mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    /// 🔹 Top Row
                    Row(
                      children: [
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children:  [
                              Row(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Expanded(
                                    flex: 8,
                                    child: Text(
                                      foodLogEntry!.foodItemWithNutrients!.description!,
                                      style: AppTheme.title14,
                                    ),
                                  ),
                                  Expanded(
                                    flex: 1,
                                    child: Container(
                                      width: 25,
                                      height: 25,
                                      decoration: BoxDecoration(
                                        shape: BoxShape.circle,
                                        border: Border.all(color: AppTheme.primaryColor, width: 1),
                                      ),
                                      child: Center(
                                        child: Image.asset(
                                          _getImageOfMealType(index: foodLogEntry!.mealType!.id),
                                          height: 15,
                                        ),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                              SizedBox(height: 8),
                              Text(
                                calories,
                                style: AppTheme.title12,
                              ),
                            ],
                          ),
                        ),


                        //Image.asset(_getImageOfMealType(index: foodLogEntry!.mealType!.id),height: 30,),
                        const SizedBox(width: 8),
                        IconButton(onPressed: () async {
                          final editData = MealEditData(
                            id: foodLogEntry!.id!,
                            name: foodLogEntry!.foodItemWithNutrients!.description!,
                            quantity: foodLogEntry!.quantity!,
                            servingUnit: foodLogEntry!.foodItemWithNutrients!.servingUnit,
                            calories: dcalories,
                            sodium: dsodium,
                            carbs: dcarbs,
                            protein: dprotein,
                            fats: dfat,
                            mealTypeId: foodLogEntry!.mealType!.id!,
                          );

                          print("➡️ Passing to AddMealPage:");
                          print(editData.name); // 👈 This prints clean JSON-like output

                          final result = await AppRouter.navigateToAddMeal(
                            context,
                            editData: editData,
                            isEditMode: true,
                          );
                        }, icon: Icon(Icons.edit, color: AppTheme.primaryColor)),
                        const SizedBox(width: 8),
                        const Icon(Icons.delete, color: AppTheme.primaryColor),
                      ],
                    ),
                    const Divider(
                      color: Colors.black12,
                      thickness: 1,
                    ),
                    /// 🔹 Nutrients Grid
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Expanded(
                          child: _NutrientItem(
                            color: AppTheme.primaryColor,
                            label: "Sodium ($sodium)",
                          ),
                        ),
                       // Spacer(),
                        Expanded(
                          child: _NutrientItem(
                            color: Colors.orange,
                            label: "Carbs ($carbs)",
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 8),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Expanded(
                          child: _NutrientItem(
                            color: Colors.blueAccent,
                            label: "Proteins ($protein)",
                          ),
                        ),
                         //Spacer(),
                         Expanded(
                          child: _NutrientItem(
                            color: Colors.yellow,
                            label: "Fats ($fat)",
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ),
        );
      },
    );
  }

  static Widget _iconCircle(IconData icon) {
    return Container(
      padding: const EdgeInsets.all(6),
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        border: Border.all(color: Colors.redAccent),
      ),
      child: Icon(icon, size: 16, color: Colors.redAccent),
    );
  }
  String _getImageOfMealType({int? index}) {
    switch (index) {
      case 21:
        return "lib/assets/breakfast.png";
      case 22:
        return "lib/assets/Lunch.png";
      case 23:
        return "lib/assets/snacks.png";
      case 24:
        return "lib/assets/dinner.png";
      default:
        return "lib/assets/All Meal.png";
    }
  }
}

class _NutrientItem extends StatelessWidget {
  final Color color;
  final String label;

  const _NutrientItem({
    required this.color,
    required this.label,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Container(
          width: 10,
          height: 10,
          decoration: BoxDecoration(
            color: color,
            shape: BoxShape.circle,
          ),
        ),
        const SizedBox(width: 6),
        Flexible(
          child: Text(
            label,
            style: deviceWidth(context)>390? AppTheme.title12:AppTheme.title10,
            overflow: TextOverflow.ellipsis,
          ),
        ),
      ],
    );
  }
}
// Utility
extension NutrientUtils on List<ActualNutrientIntake> {
  String valueOf(String name) {
    final item = firstWhere(
          (e) => (e.nutrientName ?? '').toLowerCase() == name.toLowerCase(),
      orElse: () => ActualNutrientIntake(quantity: 0, unitType: ''),
    );

    return "${(item.quantity ?? 0).toStringAsFixed(2)} ${item.unitType ?? ''}";
  }
}
extension NutrientUtilsDouble on List<ActualNutrientIntake> {
  double valueOfQuantity(String name) {
    final item = firstWhere(
          (e) => (e.nutrientName ?? '').toLowerCase() == name.toLowerCase(),
      orElse: () => ActualNutrientIntake(quantity: 0),
    );

    return item.quantity ?? 0.0;
  }
}




/// =======================
/// API
/// =======================
String buildMealLogsUrl({required int page, required int size}) {
  final now = DateTime.now();
  final date = DateFormat('dd-MM-yyyy').format(now);

  final fromDate = '$date 00:00';
  final toDate = '$date 23:59';

  return Uri.encodeFull(
    'https://qaheartthrive.schoolyug.com/api/patient-meal-logs/user-meal-logs'
        '?fromDate=$fromDate'
        '&toDate=$toDate'
        '&page=$page'
        '&size=$size',
  );
}

Future<FoodLogPageResponse> fetchMealLogs({
  required int page,
  required int size,
}) async {
  final url = buildMealLogsUrl(page: page, size: size);
  final prefs = await SharedPreferences.getInstance();
  String? token = prefs.getString('auth_token');
  // Secure Storage
  final secureStorage = SecureStorageUtils();

  String? secureStorageToken = await secureStorage.read("auth_token");
  token = token??secureStorageToken;
  final response = await http.get(
    Uri.parse(url),
    headers: {
      'Content-Type': 'application/json',
      'Authorization': 'Bearer $token',
    },
  );

  if (response.statusCode == 200) {
    return FoodLogPageResponse.fromJson(json.decode(response.body));
  } else {
    throw Exception('Failed to load data: ${response.statusCode}');
  }
}
Future<List<Nutrient>> fetchNutrientSummary({
  required String fromDate,
  required String toDate,
  required String timezone,
}) async {
  final prefs = await SharedPreferences.getInstance();
  String? token = prefs.getString('auth_token');
  // Secure Storage
  final secureStorage = SecureStorageUtils();

  String? secureStorageToken = await secureStorage.read("auth_token");
  token = token ?? secureStorageToken;
  const String _baseUrl =
      'https://qaheartthrive.schoolyug.com/api/patient-meal-logs/nutrient-summary';
  final uri = Uri.parse(_baseUrl).replace(queryParameters: {
    'fromDate': fromDate, // e.g. 22-12-2025 00:00
    'toDate': toDate, // e.g. 22-12-2025 23:59
    'timezone': timezone // Asia/Kolkata
  });

  final response = await http.get(
    uri,
    headers: {
      'Authorization': 'Bearer $token',
      'Content-Type': 'application/json',
    },
  );

  if (response.statusCode == 200) {
    final Map<String, dynamic> data = json.decode(response.body);
    final List list = data['nutrients'] ?? [];

    return list.map((e) => Nutrient.fromJson(e)).toList();
  } else {
    throw Exception(
        'Failed to load nutrients: ${response.statusCode} ${response.body}');
  }
}



