import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:heart_thrive/pages/meal-sodium/user_meal_menu_picker_page.dart';
import 'package:http/http.dart' as http;

import '../../models/home/meal_type_nutrient_model.dart';
import '../../models/meal/edit_meal_model.dart';
import '../../providers/token_provider.dart';
import '../../routes/app_router.dart';
import '../../theme/app_theme.dart';

// ---------------------------------------------------------------------------
// MODELS
// ---------------------------------------------------------------------------

class FoodItem {
  final int id;
  final String uuid;
  final int fdcId;
  final String description;
  final String? brandName;
  final double servingSize;
  final String servingUnit;
  final List<Nutrient> nutrients;

  FoodItem({
    required this.id,
    required this.uuid,
    required this.fdcId,
    required this.description,
    this.brandName,
    required this.servingSize,
    required this.servingUnit,
    required this.nutrients,
  });

  factory FoodItem.fromJson(Map<String, dynamic> json) {
    return FoodItem(
      id: json['id'] ?? 0,
      uuid: json['uuid'] ?? '',
      fdcId: json['fdcId'] ?? 0,
      description: json['description'] ?? 'Unknown Food',
      brandName: json['brandName'],
      servingSize: (json['servingSize'] as num?)?.toDouble() ?? 0.0,
      servingUnit: json['servingUnit'] ?? '',
      nutrients: (json['nutrients'] as List<dynamic>? ?? [])
          .map((e) => Nutrient.fromJson(e))
          .toList(),
    );
  }
}

class FoodListResponse {
  final List<FoodItem> content;
  final bool last;

  FoodListResponse({required this.content, required this.last});

  factory FoodListResponse.fromJson(Map<String, dynamic> json) {
    return FoodListResponse(
      content: (json['content'] as List)
          .map((e) => FoodItem.fromJson(e))
          .toList(),
      last: json['last'] ?? true,
    );
  }
}

// ---------------------------------------------------------------------------
// SERVICE
// ---------------------------------------------------------------------------

class FoodService {
  static const _baseUrl =
      'https://qaheartthrive.schoolyug.com/api/food-items/with-nutrients';

  Future<FoodListResponse> fetchFoods({
    required int page,
    required int size,
    String? search,
    required String token,
  }) async {
    final uri = Uri.parse(_baseUrl).replace(queryParameters: {
      'page': '$page',
      'size': '$size',
      if (search != null && search.isNotEmpty) 'foodItemName': search,
    });

    final response = await http.get(uri, headers: {
      'Authorization': 'Bearer $token',
    });

    if (response.statusCode != 200) {
      throw Exception('Failed to load foods');
    }

    return FoodListResponse.fromJson(jsonDecode(response.body));
  }
}

// ---------------------------------------------------------------------------
// PROVIDERS
// ---------------------------------------------------------------------------

final foodServiceProvider = Provider((_) => FoodService());

final foodProvider =
StateNotifierProvider<FoodNotifier, AsyncValue<List<FoodItem>>>(
      (ref) => FoodNotifier(ref),
);

class FoodNotifier extends StateNotifier<AsyncValue<List<FoodItem>>> {
  FoodNotifier(this.ref) : super(const AsyncLoading()) {
    loadInitial();
  }

  final Ref ref;

  int _page = 0;
  bool _hasMore = true;
  bool _loadingMore = false;
  String _search = '';

  static const _pageSize = 10;

  bool get hasMore => _hasMore;

  Future<void> loadInitial({String search = ''}) async {
    _page = 0;
    _hasMore = true;
    _search = search.trim();

    state = const AsyncLoading();

    try {
      final data = await _fetch();
      state = AsyncData(data);
    } catch (e, st) {
      state = AsyncError(e, st);
    }
  }

  Future<void> loadMore() async {
    if (!_hasMore || _loadingMore || state.isLoading) return;

    _loadingMore = true;
    final current = state.value ?? [];

    try {
      final data = await _fetch();
      _hasMore = data.length == _pageSize;
      state = AsyncData([...current, ...data]);
    } finally {
      _loadingMore = false;
    }
  }

  Future<List<FoodItem>> _fetch() async {
    final service = ref.read(foodServiceProvider);
    final token = ref.read(tokenProvider);

    if (token == null) throw Exception('No token');

    final res = await service.fetchFoods(
      page: _page,
      size: _pageSize,
      search: _search.isEmpty ? null : _search,
      token: token,
    );

    _page++;
    return res.content;
  }
}

// ---------------------------------------------------------------------------
// EXTENSIONS
// ---------------------------------------------------------------------------

extension NutrientUtils on List<Nutrient> {
  String valueOf(String name) {
    final n = firstWhere(
          (e) => (e.name ?? '').toLowerCase() == name.toLowerCase(),
      orElse: () => Nutrient(
          amount: 0, unitName: '', name: '', minValue: 0, maxValue: 0),
    );
    return '${(n.amount ?? 0).toStringAsFixed(1)}${n.unitName ?? ''}';
  }

  double qty(String name) {
    final n = firstWhere(
          (e) => (e.name ?? '').toLowerCase() == name.toLowerCase(),
      orElse: () => Nutrient(
          amount: 0, unitName: '', name: '', minValue: 0, maxValue: 0),
    );
    return n.amount ?? 0;
  }
}

// ---------------------------------------------------------------------------
// UI PAGE
// ---------------------------------------------------------------------------

class MealMenuPage extends ConsumerStatefulWidget {
  const MealMenuPage({super.key});

  @override
  ConsumerState<MealMenuPage> createState() => _MealMenuPageState();
}

class _MealMenuPageState extends ConsumerState<MealMenuPage> {
  final _searchCtrl = TextEditingController();
  Timer? _debounce;
  bool isBrowse = true;

  @override
  void initState() {
    super.initState();
    _searchCtrl.addListener(_onSearch);
  }

  void _onSearch() {
    if (!isBrowse) return;

    _debounce?.cancel();
    _debounce = Timer(const Duration(milliseconds: 500), () {
      ref
          .read(foodProvider.notifier)
          .loadInitial(search: _searchCtrl.text);
    });
  }

  @override
  void dispose() {
    _debounce?.cancel();
    _searchCtrl.dispose();
    super.dispose();
  }

  void _switchTab(bool browse) {
    _debounce?.cancel();
    setState(() => isBrowse = browse);

    if (browse) {
      ref.read(foodProvider.notifier).loadInitial(
        search: _searchCtrl.text,
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final foodAsync = ref.watch(foodProvider);
    final notifier = ref.read(foodProvider.notifier);

    return Scaffold(
      backgroundColor: const Color(0xFFF6F6F6),
      appBar: AppBar(title: const Text('Meal Menu')),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(12),
            child: Row(
              children: [
                _tab('Browse Food', isBrowse, () => _switchTab(true)),
                const SizedBox(width: 8),
                _tab('Meal Menu', !isBrowse, () => _switchTab(false)),
              ],
            ),
          ),
          if (isBrowse)
            Padding(
            padding: const EdgeInsets.all(16),
            child: Container(
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(30),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withValues(alpha: 0.05),
                    blurRadius: 8,
                  )
                ],
              ),
              child: TextField(
                controller: _searchCtrl,
                decoration: InputDecoration(
                  hintText: 'Search Food or Meal',
                  filled: true,
                  fillColor: Colors.grey.shade100,
                  hintStyle: AppTheme.title14.copyWith(fontWeight: FontWeight.normal),
                  prefixIcon: const Icon(Icons.search, size: 26, color: Colors.black54),
                  contentPadding:
                  const EdgeInsets.symmetric(vertical: 5, horizontal: 16),
                  suffixIcon: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      GestureDetector(
                          onTap: () {
                            AppRouter.navigateToAddMeal(context);
                          },
                          child: Container(
                            height: 25,
                            padding: const EdgeInsets.symmetric(horizontal: 8.0),
                            margin: const EdgeInsets.only(right: 8.0),
                            decoration: BoxDecoration(
                              color: AppTheme.primaryColor,
                              borderRadius: BorderRadius.circular(8.0),
                            ),
                            child: const Center(
                              child: Text(
                                'Custom +',
                                style: TextStyle(
                                  fontSize: 14,
                                  color: Colors.white,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ),
                          ),
                        ),
                      const SizedBox(width: 5),
                    ],
                  ),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(40.0),
                    borderSide: BorderSide(color: Colors.grey.shade300),
                  ),
                  enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(40.0),
                    borderSide: BorderSide(color: Colors.grey.shade300),
                  ),
                  focusedBorder: const OutlineInputBorder(
                    borderRadius: BorderRadius.all(Radius.circular(40.0)),
                    borderSide: BorderSide(color: AppTheme.primaryColor),
                  ),
                ),
              ),
            ),
          ),
          const SizedBox(height: 8),
          Expanded(
            child: isBrowse
                ? foodAsync.when(
              loading: () =>
              const Center(child: CircularProgressIndicator()),
              error: (e, _) => Center(child: Text('Error: $e')),
              data: (items) => NotificationListener<ScrollNotification>(
                onNotification: (s) {
                  if (s.metrics.pixels >
                      s.metrics.maxScrollExtent - 200) {
                    notifier.loadMore();
                  }
                  return false;
                },
                child: ListView.builder(
                  itemCount: items.length + 1,
                  padding: const EdgeInsets.all(12),
                  itemBuilder: (c, i) {
                    if (i == items.length) {
                      return notifier.hasMore
                          ? const Center(
                          child: Padding(
                            padding: EdgeInsets.all(16),
                            child: CircularProgressIndicator(),
                          ))
                          : const SizedBox();
                    }
                    return _FoodTile(item: items[i]);
                  },
                ),
              ),
            )
                : MealListScreen(),
          )
        ],
      ),
    );
  }

  Widget _tab(String text, bool active, VoidCallback onTap) {
    return Expanded(
      child: ElevatedButton(
        style: ElevatedButton.styleFrom(
          backgroundColor:
          active ? AppTheme.primaryColor : Colors.grey.shade200,
          foregroundColor: active ? Colors.white : Colors.black,
        ),
        onPressed: onTap,
        child: Text(text),
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// FOOD TILE
// ---------------------------------------------------------------------------

class _FoodTile extends StatelessWidget {
  final FoodItem item;
  const _FoodTile({required this.item});

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.symmetric(vertical: 6),
      child: ListTile(
        title: Text('${item.description} (${item.servingSize} ${item.servingUnit})',
            style: const TextStyle(fontWeight: FontWeight.w600)),
        subtitle: Text(
            '${item.nutrients.qty("Calories").toStringAsFixed(0)} kcal \n'
                'Contains ${item.nutrients.valueOf("Sodium")} Sodium'),
        trailing: IconButton(onPressed:() async {
          final result = await AppRouter.navigateToAddMeal(
            context,
            editData: MealEditData(
              id: item.id,
              name: item.description,
              quantity: item.servingSize.toString(),
              servingUnit: item.servingUnit,
              calories: item.nutrients.qty("Calories"),
              sodium: item.nutrients.qty("Sodium"),
              carbs:  item.nutrients.qty("Carbohydrates"),
              protein: item.nutrients.qty("Protein"),
              fats: item.nutrients.qty("Fat"),
              mealTypeId: null,
            ),
          );

          if (result == true) {

          }
        },
            icon: const Icon(Icons.add_circle, color: AppTheme.primaryColor)),
      ),
    );
  }
}
